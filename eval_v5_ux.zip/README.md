# Eval — Lead Finder (v5 backend + polished UI)

- Brave Search API (with optional SerpAPI fallback)
- LinkedIn / General / Both search modes
- Structured filters (geo, industry, roles), paging + de-dupe
- Headcount estimation & filtering (homepage/about)
- DNS/MX email validation (no SMTP)
